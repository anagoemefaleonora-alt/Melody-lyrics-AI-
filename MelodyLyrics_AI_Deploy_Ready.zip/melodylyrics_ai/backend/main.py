import os
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI

app = FastAPI(title="MelodyLyrics AI API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

class Request(BaseModel):
    language: str
    genre: str
    mood: str
    theme: str = ""
    notes: str = ""
    analysis: dict

@app.post("/api/lyrics")
def lyrics(req: Request):
    if not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(503, "Set OPENAI_API_KEY on the backend first.")
    a = req.analysis
    note_summary = ", ".join(f'{n.get("note")}{n.get("octave")} ({n.get("duration")}s)' for n in a.get("notes", [])[:70])
    prompt = f"""Write completely original, singable song lyrics in {req.language}.
Genre: {req.genre}. Mood: {req.mood}. Theme: {req.theme}.
Additional direction: {req.notes or "Keep the words memorable and natural."}
The singer supplied their own melody. Its approximate audio duration is {a.get('duration')} seconds.
Detected note events in order: {note_summary}
Create a concise verse and chorus. Respect the detected phrase order and note durations as much as possible.
Use short, natural syllabic phrases for short notes and allow longer vowels on sustained notes.
Do not claim exact note-to-syllable alignment from this approximate analysis. Do not imitate any named artist or existing song.
Return only lyrics, with section labels. Keep the language natural and idiomatic."""
    try:
        response = client.responses.create(model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"), input=prompt)
        return {"lyrics": response.output_text}
    except Exception as e:
        raise HTTPException(502, f"AI generation failed: {str(e)}")

@app.get("/health")
def health():
    return {"status": "ok", "service": "MelodyLyrics AI"}

# Serve the mobile web app and API from one HTTPS deployment.
WEB_ROOT = Path(__file__).resolve().parent.parent
app.mount("/", StaticFiles(directory=str(WEB_ROOT), html=True), name="web")
