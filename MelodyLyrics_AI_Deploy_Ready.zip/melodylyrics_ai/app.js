let audioBlob=null, audioUrl=null, recorder=null, chunks=[], analysisData=null, finalLyrics="";
const $=id=>document.getElementById(id);
const setStatus=t=>$("recordStatus").textContent=t;
$("recordBtn").onclick=async()=>{
 try{
  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
  chunks=[];recorder=new MediaRecorder(stream);
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  recorder.onstop=()=>{audioBlob=new Blob(chunks,{type:recorder.mimeType||"audio/webm"});stream.getTracks().forEach(t=>t.stop());setAudio(audioBlob);setStatus("Recording ready. Listen, then analyse your melody.");};
  recorder.start();$("recordBtn").disabled=true;$("stopBtn").disabled=false;setStatus("Recording… sing or hum your melody.");
 }catch(e){setStatus("Microphone access was blocked. Allow microphone permission or upload an audio file.");}
};
$("stopBtn").onclick=()=>{if(recorder&&recorder.state!=="inactive")recorder.stop();$("recordBtn").disabled=false;$("stopBtn").disabled=true;};
$("fileInput").onchange=e=>{const f=e.target.files[0];if(f){audioBlob=f;setAudio(f);setStatus("Audio file ready. You can analyse it now.");}};
function setAudio(blob){if(audioUrl)URL.revokeObjectURL(audioUrl);audioUrl=URL.createObjectURL(blob);$("audioPlayer").src=audioUrl;$("audioPlayer").hidden=false;$("analyseBtn").disabled=false;$("generateBtn").disabled=true;$("analysis").textContent="Ready to analyse.";$("result").textContent="Your lyrics will appear here.";}
$("analyseBtn").onclick=async()=>{
 if(!audioBlob)return; $("analyseBtn").disabled=true;$("analyseBtn").textContent="Analysing…";
 try{analysisData=await analyseAudio(audioBlob);$("analysis").textContent=formatAnalysis(analysisData);$("generateBtn").disabled=false;}
 catch(e){$("analysis").textContent="Could not analyse this audio. Try a shorter, clearer recording (5–30 seconds) or another audio format. "+e.message;}
 finally{$("analyseBtn").disabled=false;$("analyseBtn").textContent="Analyse my melody";}
};
async function analyseAudio(blob){
 const ctx=new (window.AudioContext||window.webkitAudioContext)();const buf=await ctx.decodeAudioData(await blob.arrayBuffer());const sr=buf.sampleRate, data=buf.getChannelData(0);
 const frame=Math.floor(sr*.046), hop=Math.floor(sr*.023), notes=[];
 for(let start=0;start+frame<data.length;start+=hop){
  let rms=0;for(let j=0;j<frame;j++)rms+=data[start+j]*data[start+j];rms=Math.sqrt(rms/frame);if(rms<.012)continue;
  const minLag=Math.floor(sr/1000),maxLag=Math.min(Math.floor(sr/65),frame-1);let best=0,bestCorr=0;
  for(let lag=minLag;lag<=maxLag;lag++){let c=0;for(let j=0;j<frame-lag;j++)c+=data[start+j]*data[start+j+lag];if(c>bestCorr){bestCorr=c;best=lag;}}
  if(best&&bestCorr>0){const hz=sr/best;if(hz>65&&hz<1000)notes.push({t:start/sr,hz,midi:Math.round(69+12*Math.log2(hz/440))});}
 }
 await ctx.close();if(notes.length<5)throw new Error("Not enough clear pitched sound detected.");
 const groups=[];for(const n of notes){const last=groups[groups.length-1];if(last&&Math.abs(last.midi-n.midi)<=1&&n.t-last.end<.11){last.end=n.t+.046;last.count++;}else groups.push({midi:n.midi,start:n.t,end:n.t+.046,count:1});}
 const stable=groups.filter(g=>g.count>=2);const names=["C","C♯","D","D♯","E","F","F♯","G","G♯","A","A♯","B"];
 const noteEvents=stable.slice(0,100).map(g=>({note:names[((g.midi%12)+12)%12],octave:Math.floor(g.midi/12)-1,start:+g.start.toFixed(2),duration:+(g.end-g.start).toFixed(2)}));
 const intervals=noteEvents.slice(1).map((n,i)=>n.start-noteEvents[i].start).filter(x=>x>0);
 const avg=intervals.length?intervals.reduce((a,b)=>a+b,0)/intervals.length:0;
 return {duration:+buf.duration.toFixed(2),detectedNoteCount:noteEvents.length,notes:noteEvents,approxBpm:avg?Math.round(60/avg):null,method:"Browser pitch estimation (approximate)"};
}
function formatAnalysis(a){return `Duration: ${a.duration}s\nDetected note events: ${a.detectedNoteCount}\nApproximate pulse estimate: ${a.approxBpm||"Not available"} BPM\nNotes: ${a.notes.slice(0,32).map(n=>n.note+n.octave).join(" · ")}${a.notes.length>32?" …":""}\n\nThis is an approximate guide, not a professional transcription. Humming, chords and background noise can affect detection.`;}
$("generateBtn").onclick=async()=>{
 if(!analysisData)return;
 $("generateBtn").disabled=true;$("generateBtn").textContent="Writing lyrics…";
 const payload={language:$("language").value,genre:$("genre").value,mood:$("mood").value,theme:$("theme").value,notes:$("notes").value,analysis:analysisData};
 try{
  const res=await fetch("/api/lyrics",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  if(!res.ok)throw new Error((await res.text())||"AI service unavailable");
  const data=await res.json();finalLyrics=data.lyrics;$("result").textContent=finalLyrics;
 }catch(e){finalLyrics=demoLyrics(payload);$("result").textContent=finalLyrics+"\n\n[Preview mode: connect and run the AI backend to generate custom lyrics. This preview is not guaranteed to match the melody.]";}
 $("copyBtn").disabled=false;$("downloadBtn").disabled=false;$("generateBtn").disabled=false;$("generateBtn").textContent="✦ Generate matching lyrics";
};
function demoLyrics(p){return `VERSE\nYou are the light that carries me\nYour faithful love has set me free\n\nCHORUS\nI will sing, my heart belongs to You\nThrough every night, Your love will lead me through\n\nSelected: ${p.language} · ${p.genre} · ${p.mood}\nTheme: ${p.theme||"Not specified"}\n\nConnect the backend for AI-generated lyrics tailored to your analysed melody.`;}
$("copyBtn").onclick=async()=>{await navigator.clipboard.writeText(finalLyrics);$("copyBtn").textContent="Copied!";setTimeout(()=>$("copyBtn").textContent="Copy lyrics",1400);};
$("downloadBtn").onclick=()=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([finalLyrics],{type:"text/plain"}));a.download="melodylyrics-song.txt";a.click();URL.revokeObjectURL(a.href);};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("./sw.js").catch(()=>{}));