# MelodyLyrics AI — Android-first starter

This is a working mobile-first web app (PWA) starter. On Android, open the hosted app in Chrome and choose **Add to Home screen**. The frontend can record audio, accept an audio upload, estimate pitched note events in the browser, and send the analysis to the AI backend for lyric generation.

## Important honesty about matching
The browser analysis is an approximate monophonic pitch estimate. It is a prototype, not studio-grade transcription. The AI uses note order, durations and song preferences to write lyrics, but exact syllable-to-note alignment needs a stronger alignment engine and human review. Twi, Pidgin and other languages should be tested with fluent speakers for natural phrasing.

## Run the frontend locally
Serve the project root over HTTPS (microphone access requires a secure context; localhost is also allowed). For example:
```bash
python -m http.server 8000
```
Open `http://localhost:8000`.

## Run the AI backend
From the `backend` folder:
```bash
pip install -r requirements.txt
export OPENAI_API_KEY="your-key"
uvicorn main:app --host 0.0.0.0 --port 8001
```
For local development, proxy `/api/lyrics` from the frontend host to the backend, or change the fetch URL in `app.js` to your deployed backend URL. Do not put your API key in browser JavaScript. Deploy the frontend and backend over HTTPS before using on a phone.

## Android install
1. Deploy the frontend to an HTTPS host.
2. Open its address in Chrome on Android.
3. Use Chrome menu → **Add to Home screen** (or **Install app**, if shown).
4. Allow microphone permission when recording.

## Before public release
Add user accounts, private audio storage, consent and deletion controls, rate limits, backend authentication, usage limits, robust audio transcription, tests, and privacy policy. Never expose API keys in the app.
